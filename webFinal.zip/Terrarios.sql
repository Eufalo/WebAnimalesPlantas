-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 13-06-2018 a las 21:36:03
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `Terrarios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Animales`
--

CREATE TABLE `Animales` (
  `ID_Animal` int(11) NOT NULL,
  `Nombre` varchar(255) COLLATE utf8_bin NOT NULL,
  `Reino` int(11) DEFAULT NULL,
  `Descripcion` varchar(255) COLLATE utf8_bin NOT NULL,
  `NombreCientifico` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `Animales`
--

INSERT INTO `Animales` (`ID_Animal`, `Nombre`, `Reino`, `Descripcion`, `NombreCientifico`) VALUES
(1, 'Gecko', 2, 'Gekko es un género de reptiles escamosos pertenecientes a la familia Gekkonidae. Se distribuyen por el Sudeste Asiático y Oceanía, viven en ambientes húmedos (bosques).', 'Gekko'),
(2, 'Ajolote', 1, 'El ajolote es una especie de anfibio caudado de la familia Ambystomatidae. Es endémico del sistema lacustre del valle de México y ha tenido una gran influencia en la cultura mexicana. Se encuentra en peligro crítico de extinción por la contaminación de la', 'Ambystoma mexicanum'),
(3, 'Pogona', 2, 'Pogona es un género de lagartos iguanios de la familia Agamidae nativa de las regiones áridas de Australia. Cuentan con espinas dispuestas en su cuello que pueden erizarse para amenazar a un contendiente o durante la época de celo. Pueden variar su color ', 'Pogona vitticeps');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `data_users`
--

CREATE TABLE `data_users` (
  `ID_Usuario` int(11) NOT NULL,
  `usuario` varchar(25) COLLATE utf8_bin NOT NULL,
  `password` varchar(60) COLLATE utf8_bin NOT NULL,
  `tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `data_users`
--

INSERT INTO `data_users` (`ID_Usuario`, `usuario`, `password`, `tipo`) VALUES
(1, 'admin1234', '$2y$10$VZLbIVRyHj0rKswY913roO9h2V2k4aivQTDDSHyFqYc06Jwt8G1aC', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Paises_ID`
--

CREATE TABLE `Paises_ID` (
  `ID_Pais` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `Nombre` varchar(36) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `Paises_ID`
--

INSERT INTO `Paises_ID` (`ID_Pais`, `Nombre`) VALUES
(' AFG', ' Afghanistan'),
(' AGO', ' Angola'),
(' ALB', ' Albania'),
(' ARE', ' United Arab Emirates'),
(' ARG', ' Argentina'),
(' ARM', ' Armenia'),
(' ATA', ' Antarctica'),
(' ATF', ' French Southern and Antarctic Lands'),
(' AUS', ' Australia'),
(' AUT', ' Austria'),
(' AZE', ' Azerbaijan'),
(' BDI', ' Burundi'),
(' BEL', ' Belgium'),
(' BEN', ' Benin'),
(' BFA', ' Burkina Faso'),
(' BGD', ' Bangladesh'),
(' BGR', ' Bulgaria'),
(' BHS', ' The Bahamas'),
(' BIH', ' Bosnia and Herzegovina'),
(' BLR', ' Belarus'),
(' BLZ', ' Belize'),
(' BMU', ' Bermuda'),
(' BOL', ' Bolivia'),
(' BRA', ' Brazil'),
(' BRN', ' Brunei'),
(' BTN', ' Bhutan'),
(' BWA', ' Botswana'),
(' CAF', ' Central African Republic'),
(' CAN', ' Canada'),
(' CHE', ' Switzerland'),
(' CHL', ' Chile'),
(' CHN', ' China'),
(' CIV', ' Ivory Coast'),
(' CMR', ' Cameroon'),
(' COD', ' Democratic Republic of the Congo'),
(' COG', ' Republic of the Congo'),
(' COL', ' Colombia'),
(' CRI', ' Costa Rica'),
(' CUB', ' Cuba'),
(' NCYP', ' Northern Cyprus'),
(' CYP', ' Cyprus'),
(' CZE', ' Czech Republic'),
(' DEU', ' Germany'),
(' DJI', ' Djibouti'),
(' DNK', ' Denmark'),
(' DOM', ' Dominican Republic'),
(' DZA', ' Algeria'),
(' ECU', ' Ecuador'),
(' EGY', ' Egypt'),
(' ERI', ' Eritrea'),
(' ESP', ' Spain'),
(' EST', ' Estonia'),
(' ETH', ' Ethiopia'),
(' FIN', ' Finland'),
(' FJI', ' Fiji'),
(' FLK', ' Falkland Islands'),
(' FRA', ' France'),
(' GAB', ' Gabon'),
(' GBR', ' United Kingdom'),
(' GEO', ' Georgia'),
(' GHA', ' Ghana'),
(' GIN', ' Guinea'),
(' GMB', ' Gambia'),
(' GNB', ' Guinea Bissau'),
(' GNQ', ' Equatorial Guinea'),
(' GRC', ' Greece'),
(' GRL', ' Greenland'),
(' GTM', ' Guatemala'),
(' GUF', ' French Guiana'),
(' GUY', ' Guyana'),
(' HND', ' Honduras'),
(' HRV', ' Croatia'),
(' HTI', ' Haiti'),
(' HUN', ' Hungary'),
(' IDN', ' Indonesia'),
(' IND', ' India'),
(' IRL', ' Ireland'),
(' IRN', ' Iran'),
(' IRQ', ' Iraq'),
(' ISL', ' Iceland'),
(' ISR', ' Israel'),
(' ITA', ' Italy'),
(' JAM', ' Jamaica'),
(' JOR', ' Jordan'),
(' JPN', ' Japan'),
(' KAZ', ' Kazakhstan'),
(' KEN', ' Kenya'),
(' KGZ', ' Kyrgyzstan'),
(' KHM', ' Cambodia'),
(' KOR', ' South Korea'),
(' CS-KM', ' Kosovo'),
(' KWT', ' Kuwait'),
(' LAO', ' Laos'),
(' LBN', ' Lebanon'),
(' LBR', ' Liberia'),
(' LBY', ' Libya'),
(' LKA', ' Sri Lanka'),
(' LSO', ' Lesotho'),
(' LTU', ' Lithuania'),
(' LUX', ' Luxembourg'),
(' LVA', ' Latvia'),
(' MAR', ' Morocco'),
(' MDA', ' Moldova'),
(' MDG', ' Madagascar'),
(' MEX', ' Mexico'),
(' MKD', ' Macedonia'),
(' MLI', ' Mali'),
(' MLT', ' Malta'),
(' MMR', ' Myanmar'),
(' MNE', ' Montenegro'),
(' MNG', ' Mongolia'),
(' MOZ', ' Mozambique'),
(' MRT', ' Mauritania'),
(' MWI', ' Malawi'),
(' MYS', ' Malaysia'),
(' NAM', ' Namibia'),
(' NCL', ' New Caledonia'),
(' NER', ' Niger'),
(' NGA', ' Nigeria'),
(' NIC', ' Nicaragua'),
(' NLD', ' Netherlands'),
(' NOR', ' Norway'),
(' NPL', ' Nepal'),
(' NZL', ' New Zealand'),
(' OMN', ' Oman'),
(' PAK', ' Pakistan'),
(' PAN', ' Panama'),
(' PER', ' Peru'),
(' PHL', ' Philippines'),
(' PNG', ' Papua New Guinea'),
(' POL', ' Poland'),
(' PRI', ' Puerto Rico'),
(' PRK', ' North Korea'),
(' PRT', ' Portugal'),
(' PRY', ' Paraguay'),
(' QAT', ' Qatar'),
(' ROU', ' Romania'),
(' RUS', ' Russia'),
(' RWA', ' Rwanda'),
(' ESH', ' Western Sahara'),
(' SAU', ' Saudi Arabia'),
(' SDN', ' Sudan'),
(' SSD', ' South Sudan'),
(' SEN', ' Senegal'),
(' SLB', ' Solomon Islands'),
(' SLE', ' Sierra Leone'),
(' SLV', ' El Salvador'),
('SOMD', ' Somaliland'),
(' SOM', ' Somalia'),
(' SRB', ' Republic of Serbia'),
(' SUR', ' Suriname'),
(' SVK', ' Slovakia'),
(' SVN', ' Slovenia'),
(' SWE', ' Sweden'),
(' SWZ', ' Swaziland'),
(' SYR', ' Syria'),
(' TCD', ' Chad'),
(' TGO', ' Togo'),
(' THA', ' Thailand'),
(' TJK', ' Tajikistan'),
(' TKM', ' Turkmenistan'),
(' TLS', ' East Timor'),
(' TTO', ' Trinidad and Tobago'),
(' TUN', ' Tunisia'),
(' TUR', ' Turkey'),
(' TWN', ' Taiwan'),
(' TZA', ' United Republic of Tanzania'),
(' UGA', ' Uganda'),
(' UKR', ' Ukraine'),
(' URY', ' Uruguay'),
(' USA', ' United States of America'),
(' UZB', ' Uzbekistan'),
(' VEN', ' Venezuela'),
(' VNM', ' Vietnam'),
(' VUT', ' Vanuatu'),
(' PSE', ' West Bank'),
(' YEM', ' Yemen'),
(' ZAF', ' South Africa'),
(' ZMB', ' Zambia'),
(' ZWE', ' Zimbabwe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Plantas`
--

CREATE TABLE `Plantas` (
  `ID_Planta` int(11) NOT NULL,
  `Nombre` varchar(255) COLLATE utf8_bin NOT NULL,
  `Familia` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `Descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `NombreCientifico` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `Plantas`
--

INSERT INTO `Plantas` (`ID_Planta`, `Nombre`, `Familia`, `Descripcion`, `NombreCientifico`) VALUES
(1, 'Jarrito enano', 'Cephalotaceae', 'El género monotípico Cephalotus es una planta insectívora endémica de Australia Occidental. Ocurre en los márgenes de los humedales en el rincón sudoccidental de Australia Occidental. En esta parte del país se registra un índice elevado de precipi', 'Cephalotus follicularis'),
(2, 'Estrella de mar', 'Bromeliaceae', 'Es una bromelia terrestre que tiene un encanto especial. Tiene un crecimiento lento, y es una especie perenne.  Las hojas nacen en roseta, formando una superposición que asemejan estrellas. Tienen un dibujo rayado muy característico de color crema princip', 'Cryptanthus Bivittatus'),
(3, 'Pikopiko', 'Aspleniaceae', 'El pikopiko deja crecer pequeños bulbillos encima de sus frondas. Una vez que han crecido alrededor de 5 cm, ésos vástagos se caen y con el suelo provisto donde aterrizarán y se enterrarán, el cual debe mantenerse húmedo, entonces se desarrollará un siste', 'Asplenium Bulbiferum'),
(4, 'Nigrescens', 'Asparagáceas', 'Es una planta de hoja perenne que crece de un corto rizoma y tiene mechones de hojas, de la que surgen flores en racimos en el tallo corto por encima de las hojas. Sus hojas cambian de verde a morado oscuro (casi negro) y puede crecer hasta los 20 cm de l', 'Ophiopogon Planiscapus Nigrescens');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PlantaVsAnimal`
--

CREATE TABLE `PlantaVsAnimal` (
  `ID` int(11) NOT NULL,
  `ID_Planta` int(11) NOT NULL,
  `ID_Animal` int(11) NOT NULL,
  `Comentario` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pruebas`
--

CREATE TABLE `pruebas` (
  `id_Prueba` int(2) NOT NULL,
  `nombre` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `pruebas`
--

INSERT INTO `pruebas` (`id_Prueba`, `nombre`) VALUES
(1, 'Doe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Stock`
--

CREATE TABLE `Stock` (
  `ID_Stock` int(11) NOT NULL,
  `ID_Producto` int(11) NOT NULL,
  `Categoria` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Terrarios`
--

CREATE TABLE `Terrarios` (
  `ID_Terrario` int(11) NOT NULL,
  `Nombre` varchar(20) COLLATE utf8_bin NOT NULL,
  `Alto` decimal(10,0) NOT NULL,
  `Ancho` decimal(10,0) NOT NULL,
  `Largo` decimal(10,0) NOT NULL,
  `Descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `Tipo` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `Terrarios`
--

INSERT INTO `Terrarios` (`ID_Terrario`, `Nombre`, `Alto`, `Ancho`, `Largo`, `Descripcion`, `Tipo`) VALUES
(1, 'terrariodesierto1', '40', '90', '40', 'Gecko; Pogona', 1),
(2, 'terrariodesierto2', '40', '90', '40', 'Gecko; Pogona', 1),
(3, 'terrariodesierto3', '40', '90', '40', 'Gecko; Pogona', 1),
(4, 'terrariodesierto4', '90', '80', '350', 'Pogona', 1),
(5, 'acuario3', '30', '50', '40', 'Ajolote', 7),
(6, 'acuario2', '50', '40', '120', 'Ajolote', 7),
(7, 'acuario1', '50', '40', '120', 'Ajolote', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TerrarioVsAnimal`
--

CREATE TABLE `TerrarioVsAnimal` (
  `ID` int(11) NOT NULL,
  `ID_Terrario` int(11) NOT NULL,
  `ID_Animal` int(11) NOT NULL,
  `Comentario` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `TerrarioVsAnimal`
--

INSERT INTO `TerrarioVsAnimal` (`ID`, `ID_Terrario`, `ID_Animal`, `Comentario`) VALUES
(1, 1, 1, NULL),
(2, 1, 3, NULL),
(3, 2, 1, NULL),
(4, 2, 3, NULL),
(5, 3, 3, NULL),
(6, 3, 1, NULL),
(7, 4, 3, NULL),
(8, 5, 2, NULL),
(9, 6, 2, NULL),
(10, 7, 2, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TerrarioVsPlantas`
--

CREATE TABLE `TerrarioVsPlantas` (
  `ID` int(11) NOT NULL,
  `ID_Terrario` int(11) NOT NULL,
  `ID_Planta` int(11) NOT NULL,
  `Comentario` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Ubicaciones`
--

CREATE TABLE `Ubicaciones` (
  `ID_Producto` int(11) NOT NULL,
  `Categoria` int(11) NOT NULL,
  `ID_Ubicacion` int(11) NOT NULL,
  `Localizacion` varchar(6) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `Ubicaciones`
--

INSERT INTO `Ubicaciones` (`ID_Producto`, `Categoria`, `ID_Ubicacion`, `Localizacion`) VALUES
(1, 0, 1, 'AUS'),
(2, 0, 5, 'ARG'),
(2, 0, 6, 'PER'),
(2, 0, 7, 'BRA'),
(2, 0, 8, 'GIN'),
(3, 0, 9, 'NZL'),
(4, 0, 13, 'JPN'),
(1, 1, 17, 'CHN'),
(1, 1, 18, 'AUS'),
(1, 1, 19, 'GIN'),
(1, 1, 20, 'COD'),
(2, 1, 21, 'MEX'),
(3, 1, 25, 'AUS');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Animales`
--
ALTER TABLE `Animales`
  ADD PRIMARY KEY (`ID_Animal`);

--
-- Indices de la tabla `data_users`
--
ALTER TABLE `data_users`
  ADD PRIMARY KEY (`ID_Usuario`);

--
-- Indices de la tabla `Plantas`
--
ALTER TABLE `Plantas`
  ADD PRIMARY KEY (`ID_Planta`);

--
-- Indices de la tabla `PlantaVsAnimal`
--
ALTER TABLE `PlantaVsAnimal`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `Stock`
--
ALTER TABLE `Stock`
  ADD PRIMARY KEY (`ID_Stock`);

--
-- Indices de la tabla `Terrarios`
--
ALTER TABLE `Terrarios`
  ADD PRIMARY KEY (`ID_Terrario`);

--
-- Indices de la tabla `TerrarioVsAnimal`
--
ALTER TABLE `TerrarioVsAnimal`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `TerrarioVsPlantas`
--
ALTER TABLE `TerrarioVsPlantas`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `Ubicaciones`
--
ALTER TABLE `Ubicaciones`
  ADD PRIMARY KEY (`ID_Ubicacion`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Animales`
--
ALTER TABLE `Animales`
  MODIFY `ID_Animal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `Plantas`
--
ALTER TABLE `Plantas`
  MODIFY `ID_Planta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `PlantaVsAnimal`
--
ALTER TABLE `PlantaVsAnimal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `Stock`
--
ALTER TABLE `Stock`
  MODIFY `ID_Stock` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `Terrarios`
--
ALTER TABLE `Terrarios`
  MODIFY `ID_Terrario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `TerrarioVsAnimal`
--
ALTER TABLE `TerrarioVsAnimal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `TerrarioVsPlantas`
--
ALTER TABLE `TerrarioVsPlantas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `Ubicaciones`
--
ALTER TABLE `Ubicaciones`
  MODIFY `ID_Ubicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
